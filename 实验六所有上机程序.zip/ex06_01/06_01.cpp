#include<iostream.h>
void print()
{
	cout<<"Turbo C"<<endl;
}
void main()
{
	void print();
	print();
}