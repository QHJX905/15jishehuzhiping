#include<iostream.h>
void main()
{
	int i=1,s=0,n;
	cin>>n;
	do
	{
		s=s+i;
		i++;
	}while(i<=n);
	cout<<"1+2+3+...+"<<n<<"="<<s<<endl;
}