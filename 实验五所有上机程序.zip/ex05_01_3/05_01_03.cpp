#include<iostream.h>
void main()
{
	double i=1,s=0,n=99;
	while(i<=n)
	{
		s=s+i;
		i++;
	}
	cout<<"1+2+3+...+"<<n<<"="<<s<<endl;
}