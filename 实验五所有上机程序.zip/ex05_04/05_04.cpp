#include<iostream.h>
void main()
{
	int i=1,s=1;
	while(i<=100)
	{
		s=s+i*i;
			i++;
	}
	cout<<"1^2+2^2+3^2+...+100^2="<<s<<endl;
}