#include <iostream.h>
void main()
{
	int a,b,c,d;
	cout<<"please input a,b:"<<endl;
	cin>>a>>b;
	c=a>b?b:a;
	d=a>b?a:b;
	cout<<"c="<<c<<","<<"d="<<d<<endl;
}



