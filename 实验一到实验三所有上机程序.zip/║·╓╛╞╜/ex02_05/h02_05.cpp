#include "iostream.h"
#include "iomanip.h"
void main()
{
	char ch='A';
	cout<<setw(1)<<ch<<endl
		<<setw(2)<<ch<<endl;
	cout<<setfill('*');
	cout<<setw(2)<<ch<<endl
        <<setw(3)<<ch<<endl;
	cout<<setfill(' ');
}
