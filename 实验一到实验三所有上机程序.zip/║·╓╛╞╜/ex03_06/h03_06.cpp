#include <iostream.h>
#include <iomanip.h>
void main()
{
float r,l,s,pi;
cin>>r;
pi=3.14159;
l=2*pi*r;
s=pi*r*r;
cout<<setiosflags(ios::fixed)<<setprecision(4)<<"1="<<setw(8)<<1<<endl;
cout<<setiosflags(ios::fixed)<<setprecision(4)<<"s="<<setw(8)<<1<<endl;
}
