#include <iostream.h>
void main()
{
	int a,b;
	a=35;
	b=4;
	cout<<a<<"+"<<b<<"="<<a+b<<endl;
	cout<<a<<"-"<<b<<"="<<a-b<<endl;
    cout<<a<<"*"<<b<<"="<<a*b<<endl;
    cout<<a<<"/"<<b<<"="<<a/b<<endl;
    cout<<a<<"%"<<b<<"="<<a%b<<endl;
}