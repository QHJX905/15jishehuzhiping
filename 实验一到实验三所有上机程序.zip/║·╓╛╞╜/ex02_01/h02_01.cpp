#include <iostream.h>
void main()
{
	cout<<"Where "
	<<"are "
	<<"you "
	<<"come "
	<<"from?"
	<<endl;
}