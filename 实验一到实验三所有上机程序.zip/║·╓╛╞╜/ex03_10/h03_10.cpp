#include<iostream.h>
#include<math.h>
void main()
{
	float a,b,c,s,S;
	cout<<"Please inputa,b,c:";
	cin>>a>>b>>c;
	s=(a+b+c)/2;
	S=sqrt(s*(s-a)*(s-b)*(s-c));
	cout<<"�����ε����:"<<"S="<<S<<endl;
}