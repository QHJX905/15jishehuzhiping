#include <iostream.h>
void main()
{
	int number=1001;
	cout<<"Decimal:"<<dec<<number<<endl
		<<"Hexadecimal:"<<hex<<number<<endl
		<<"Octal:"<<oct<<number<<endl;
}