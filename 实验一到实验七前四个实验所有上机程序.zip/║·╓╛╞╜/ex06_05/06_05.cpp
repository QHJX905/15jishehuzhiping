#include<iostream.h>
void change(int a,int b,int c);
void main()
{
	int a,b,c;
	a=1,b=2,c=3;
	cout<<"(1)a="<<a<<","<<"b="<<b<<","<<"c="<<c<<endl;
	change(a,b,c);
	cout<<"(4)a="<<a<<","<<"b="<<b<<","<<"c="<<c<<endl;
}
void change(int a,int b,int c)
{
	cout<<"(2)a="<<a<<","<<"b="<<b<<","<<"c="<<c<<endl;
	a=a+1;
	b=b+2;
	c=c+3;
    cout<<"(3)a="<<a<<","<<"b="<<b<<","<<"c="<<c<<endl;
}