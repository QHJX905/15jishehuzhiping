#include <iostream.h>
#include <iomanip.h>
void main()
{
	double amount=22.0/7;
	cout<<amount<<endl;
	cout<<setprecision(0)<<amount<<endl
		<<setprecision(1)<<amount<<endl
		<<setprecision(2)<<amount<<endl
		<<setprecision(3)<<amount<<endl
		<<setprecision(4)<<amount<<endl; 
	cout<<setiosflags(ios::fixed)<<setprecision(8)<<amount<<endl;
	cout.unsetf(ios::fixed); 
	cout<<setiosflags(ios::scientific)<<setprecision(4)<<amount<<endl;
	cout<<setiosflags(ios::fixed)<<setprecision(6)<<amount; 
}