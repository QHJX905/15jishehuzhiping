#include<iostream.h>
void f(int);
void main()
{
	int i;
	for(i=1;i<=5;i++)
	f(i);
}
void f(int j)
{
	static int a=100;
	int k=1;
	++k;
	cout<<a<<"+"<<k<<"+"<<j<<"="<<a+k+j<<endl;
	a+=10;
}