#include<iostream.h>
int inputScore(int n);
int average(int,int);
void output(int);
void main()
{
	int n,sum,ave;
    cout<<"������γ���Ŀn"<<endl;
	cin>>n;
	sum=inputScore(n);
	ave=average(sum,n);
	output(ave);
}
int inputScore(int n)
{
	int m,sum=0;
	for(int i=1;i<=n;i++)
	{
    cout<<"������γ�"<<i<<"�ĳɼ�:"<<endl;
    cin>>m;
	cout<<"�γ�"<<i<<"�ĳɼ�:"<<m<<endl;
	sum=sum+m;
	}
	return sum;
}
int average(int sum,int n)
{
	int x;
	x=sum/n;
	return (int)x;
}
void output(int ave)
{
	cout<<"ave="<<ave<<endl;
}
