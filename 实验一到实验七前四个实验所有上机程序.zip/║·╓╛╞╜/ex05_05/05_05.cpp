
#include<iostream.h>
void main()
{
	double s=0,t=0;
	int m=1,n=2,p=1,q;
	while(p<=20)
	{
		t=m/(double)n;
		s=s+t;
		q=m;
		m=n;
		n=p+m;
		p++;
	}
	cout<<"1/2+2/3+3/5+...+"<<q<<"/"<<m<<"="<<s<<endl;
}
	
