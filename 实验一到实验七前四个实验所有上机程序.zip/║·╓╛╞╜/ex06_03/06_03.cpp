
#include<iostream.h>
void fun(int,int,int);
void main()
{int x,y,z;
   x=4;y=12;z=6;
   fun(x,y,z);
   cout<<"x="<<x<<","<<"y="<<y<<","<<"z="<<z<<endl;
}
void fun(int i,int j,int k)
{int t;
 t=(i+j+k)/3;
 cout<<"t="<<t<<endl;
}