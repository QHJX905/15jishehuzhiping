#include<iostream.h>
void p1();
void p2();
int a=2;
void main()
{
	cout<<"(1)a="<<a<<endl;
	p1();
	p2();
	cout<<"(4)a="<<a<<endl;
}
void p1()
{
	a=a*a;
	cout<<"(2)a="<<a<<endl;
}
void p2()
{
	a=a*a*a;
    cout<<"(3)a="<<a<<endl;
}