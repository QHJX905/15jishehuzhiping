#include<iostream.h>
void main()
{
	int i=1,s=0,n;
	cin>>n;
	while(i<=n)
	{
		s=s+i;
		i++;
	}
	cout<<"1+2+3+...+"<<n<<"="<<s<<endl;
}