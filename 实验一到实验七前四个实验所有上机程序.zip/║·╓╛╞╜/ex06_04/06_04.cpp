#include<iostream.h>
#include<iomanip.h>
float power(float,int);
void main()
{
	float x,y;
	int n;
	cin>>x>>n;
	y=power(x,n);
	cout<<setiosflags(ios::fixed)<<setprecision(2)<<y<<endl;
}
float power(float x,int n)
{
	int i;
	float t;
	t=1.0;
	for(i=1;i<=n;i++)
		t=t*x;
	return t;
}                          