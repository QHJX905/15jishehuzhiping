#include<iostream.h>
void main()
{
	long double n,s,i;
	s=1;
	i=1;
	cout<<"Please input n:"<<endl;
	cin>>n;
	while(i<=n)
	{
		s=s*i;
		i++;
	}
	cout<<n<<"!="<<s<<endl;
}

