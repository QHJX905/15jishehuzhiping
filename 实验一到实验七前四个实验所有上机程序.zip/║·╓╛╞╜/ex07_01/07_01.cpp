#include<iostream.h>
void main()
{
	int i,a[5];
	a[0]=2;a[1]=3;a[2]=5;a[4]=10;
	for(i=0;i<=4;i++)
	   cout<<"a["<<i<<"]="<<a[i]<<endl;
}