#include<iostream.h>
void main()
{
	int x,t;
	cout<<"please input x:"<<endl;
	x=10;
	t=x&&x>10;
    cout<<"t="<<t<<endl;
}
