#include<iostream.h>
#include<iomanip.h>
void main()
{
	float x,y;
	cin>>x;
	if(x<=10)
		y=2*x;
	else
	  if(x<=0)
		  y=2+x;
	  else
		  if(x<=10)
			  y=x-12;
		  else
			  y=x/10;
    cout<<setiosflags(ios::showpoint)<<"x="<<x<<","<<"y="<<y<<endl;
}

