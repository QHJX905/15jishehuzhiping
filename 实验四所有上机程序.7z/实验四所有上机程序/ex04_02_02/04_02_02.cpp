#include<iostream.h>
void main()
{
	int a,b,c;
	cout<<"Please input a,b,c:"<<endl;
    cin>>a>>b>>c;
	if(a>b&&a>c)
	cout<<a<<endl;
	else if(b>c)
	cout<<b<<endl;
	     else
         cout<<c<<endl;
}