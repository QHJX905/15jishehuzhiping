#include<iostream.h>
void main()
{
	int x,y,t;
	cout<<"please input x,y:"<<endl;
	x=2;
	y=0;
	t=x||(y=y+1);
    cout<<"t="<<t<<"y="<<y<<endl;
}