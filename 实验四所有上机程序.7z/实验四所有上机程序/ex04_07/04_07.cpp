#include<iostream.h>
void main ()
{
	int year,month,day,leap,n;
	cout<<"Please input year,month,day:"<<endl;
	cin>>year>>month>>day;
	if(year%400==0||(year%4==0&&year%100!=0))
	    leap=1;
	else
	    leap=0;
	switch(month)
	{
	case 1:n=0;break;
    case 2:n=31;break;
	case 3:n=59;break;
	case 4:n=90;break;
	case 5:n=120;break;
	case 6:n=151;break;
	case 7:n=181;break;
	case 8:n=212;break;
	case 9:n=243;break;
	case 10:n=273;break;
	case 11:n=304;break;
	case 12:n=334;break;
	}
	n=n+day;
	if(month<3)
		cout<<"�����Ǹ���ĵ� "<<n<<" ��"<<endl;
	else
	{
	switch(leap)
	{
		case 0:	cout<<"�����Ǹ���ĵ� "<<n<<" ��"<<endl;break;
		case 1:	cout<<"�����Ǹ���ĵ� "<<n+1<<" ��"<<endl;break;
	}
	}
}
