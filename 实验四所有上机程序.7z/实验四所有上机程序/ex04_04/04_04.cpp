#include <iostream.h>
void main ()
{
	int a,b,c;
    cin>>a>>b>>c;
	switch(a)
	{
	case 1:
	case 2:
    case 3:cout<<b<<"+"<<c<<"="<<b+c<<endl;
	case 4:cout<<b<<"-"<<c<<"="<<b-c<<endl;
	case 5:cout<<b<<"*"<<c<<"="<<b*c<<endl;break;
	case 6:cout<<b<<"/"<<c<<"="<<b/c<<endl;break;
	default:cout<<"a��ֵ����ȷ!"<<endl;
	}
}