#include<iostream.h>
void main()
{
	int a,b;
	cin>>a>>b;
	if(a>b)cout<<a<<endl;
	else cout<<b<<endl;
}
